#include <iostream>
#include "interpreter.hpp"

using namespace std;

int main()
{
    cout << "MC1 Version: " << mc1::version() << endl;
    return 0;
}
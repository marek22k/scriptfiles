#ifndef INTERPRETER_HPP
#define INTERPRETER_HPP

#include <string>

namespace mc1
{
    int version();
    std::string interpret();
}

#endif  // INTERPRETER_HPP
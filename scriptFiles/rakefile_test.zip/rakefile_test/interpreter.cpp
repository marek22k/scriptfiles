#include "interpreter.hpp"
#include <string>

namespace mc1
{
    int version()
    {
        return 1;
    }
    std::string interpret()
    {
        // Interpret code ...
        return "";
    }
}
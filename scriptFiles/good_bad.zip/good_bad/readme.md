good_bad
========

Der Autor der good_bad Programme ist Marek K�the
The author of the good_bad programs is Marek K�the
Die Website von Marek K�the ist mk16.de und seine E-Mail-Addresse ist m.k@mk16.de.
The website of Marek K�the is mk16.de and his e-mail address is m.k@mk16.de.

Die Programme sind in den folgenden Sprachen verf�gbar:
The programs are available in the following languages:
* C (c)
* C++ (cpp)
* C# (cs)
* Java (java)
* Perl (pl)
* Python (py)
* Ruby (rb)
* Visual Basic (vb)
* Row program (xcp)

Download: [test.mk16.de/scriptFiles/good_bad/](http://test.mk16.de/scriptFiles/good_bad/ "Download")
#!/usr/bin/python
# -*- coding: UTF-8 -*-

# The author of this program is Marek Küthe
# Website: mk16.de
# E-Mail: m.k@mk16.de

num = int(input("Hello User! Enter a number:\n"))

if num < 0:
	print "The number ist crazy!"
elif num%2 == 0:
	print "The number is good!"
else:
	print "The number is bad!"
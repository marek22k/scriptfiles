mbfinterpreter v1.0 README
==========================

English:
    The program mbfinterpreter was written on 25/02/2018 by Marek K. in the C programming language.
    The program supports nested loops.
    The maximum size of the input/output data is 256 KB.
    Example: mbfinterpreter Hello_World.bf

German:
    Das Programm mbfinterpreter wurde am 25/02/2018 von Marek K. in der Programmiersprache C geschrieben.
    Das Programm unterstuetzt verschachtelte Schleifen.
    Die maximale Groesze der Ein-/Ausgabedaten betraegt 256KB.
    Beispiel: mbfinterpreter Hello_World.bf
bfinterpreter v1.0
The author of this program is Marek K.
Nested loops possible.

Errorcode 0x0001: No code

Example: bfinterpreter Hello_World.bf
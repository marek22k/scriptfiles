MINI_IO_IA_PROGRAM
==================

Deutsch:
Mini-Input-Output-Interactive-Program ist eine kleines Programm, welches von Marek K. am 24/10/2018 entwickelt wurde.
Es liest mittels dem m_tclinterface Sprach-Daten aus einer Datei("language.tcl") und fragt den Benutzer, nach Namen und Gemuesztzzustand und antwortet denentsprechend.
Dabei werden auch Funktionen der C++-Standertbibliothek benutzt.

Das Programm kann normal geoeffnet werden.
Wichtig ist das eine Datei namens "language.tcl" mit den Sprach-Daten im gleiuchen Verzeichnis verhanden ist.

Standertgemaesz sind drei Sprach-Daten-Dateien mitgeliefert.
Einmal Deutsch, Jugendsprachliches Deutsch und Englisch.
Es kann auch eine eigene Sprache Datei angefasst werden.

English:
Mini-Input-Output-Interactive-Program is a small program developed by Marek K. on 24/10/2018.
It reads voice data from a file ("language.tcl") using the m_tclinterface and asks the user for name and state of conscience and responds accordingly.
It also uses functions of the C ++ library.

The program can be opened normally.
It is important that a file called "language.tcl" with the language data in the gleiuchen directory is verhanden.

According to the standards, three voice data files are included.
Once German, German as spoken German and English.
It can also be a custom language file touched.
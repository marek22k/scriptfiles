#define MSG1 "   |   In welcher Einheit gibst du die Zahl ein? 1 = Dutzend; 2 = Gros; 3 = Stueck; Deine Eingabe: "  // Message 1
#define MSG2 "   |        Bitte gebe die Anzahl ein? Deine Eingabe: "                                              // Message 2
#define MSG3 "      |                           Einheitenumrechnungen                                                  |\n      |                          12 Stueck sind 1 Dutzend                                                |\n      |                          144 Stueck sind 1 Gros                                                  |"  // Message 3

#define ERR1 "Es ist ein fehler aufgetreten: Du hast eine Ungueltige Eingabe gemacht; Fuer weitere Informationen wende dich an den Entwickler des Programms; Fehlercode: 0x0001;"
#define ERR1then abort
#define ERR1Parameter

#define wordDOZEN "Dutzend"  //  Set word for Dozen
#define wordGROS "Gros"     //  Set word for Gros
#define wordBIT "Stueck"   //  Set word for Bit
#define wordARE "sind"    //  Set word for "are"

#define B1 "   "          //  BLOCK 1
#define B2 "      "      //  BLOCK 2
#define B3 "         "  //  BLOCK 3

#define NL " "  //  Set NL(null) on " "

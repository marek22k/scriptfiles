#define MSG1 "   |   In which unit do you enter the number? 1 = Dozen; 2 = Gros; 3 = Bit; Your input: "  // Message 1
#define MSG2 "   |        Please enter the number? Your input: "                                              // Message 2
#define MSG3 "      |                           unit conversions                                                       |\n      |                          12 Bits are 1 Dozen                                                     |\n      |                          144 Bits are 1 Gros                                                     |"  // Message 3

#define ERR1 "An error has occurred: You have made an invalid entry; For more information, contact the developer of the program; Errorcode: 0x0001;"
#define ERR1then abort
#define ERR1Parameter

#define wordDOZEN "Dozen"  //  Set word for Dozen
#define wordGROS "Gros"     //  Set word for Gros
#define wordBIT "Bit"   //  Set word for Bit
#define wordARE "are"    //  Set word for "are"

#define B1 "   "          //  BLOCK 1
#define B2 "      "      //  BLOCK 2
#define B3 "         "  //  BLOCK 3

#define NL " "  //  Set NL(null) on " "

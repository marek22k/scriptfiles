class Allocate
  VERSION = "1.0"
end

require "allocate/allocate"